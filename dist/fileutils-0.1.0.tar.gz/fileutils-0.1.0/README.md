# fileutils

Small utilities for working with files and directories.

Currently provides a helper to list files in one or more directories,
optionally filtered by file extension or file type.

Installation (local development)

    pip install -e .

Usage

    from fileutils import in_dir

    # All files in current directory
    files = in_dir()

    # All Python files
    files = in_dir(extensions=[".py"])

    # Files by type
    files = in_dir(types=["code"])

    # Multiple directories
    files = in_dir(directories=["src", "tests"], types=["code"])

Behavior

- Defaults to the current directory (.)
- If no extensions or types are provided, all files are returned
- If both are provided, the result is the union of both filters
- Only files are returned (directories are ignored)

Supported types

Common file groups such as:
- code
- text
- image
- pdf
- audio
- video
- archive

See source for the full mapping.

License

MIT
