# fileutils/__init__.py

from .files import in_dir

__all__ = ["in_dir"]
